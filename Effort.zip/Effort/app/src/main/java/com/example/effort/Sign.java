package com.example.effort;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Sign extends AppCompatActivity implements View.OnClickListener {

    private EditText emailText,mPasswordText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign);


        emailText=findViewById(R.id.Email);
        mPasswordText=findViewById(R.id.password);

        findViewById(R.id.btjoin).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

    }
}
